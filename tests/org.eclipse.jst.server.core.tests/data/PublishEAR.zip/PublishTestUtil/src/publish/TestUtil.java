package publish;

public class TestUtil {
	public static String sayHi(String s) {
		return "Hi, " + s;
	}
}