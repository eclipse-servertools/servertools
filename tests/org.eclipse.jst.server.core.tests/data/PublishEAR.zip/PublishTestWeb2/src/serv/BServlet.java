package serv;

public class BServlet {

}
