package serv;

public class AServlet {

}
