package ejbs;

/**
 * Home interface for Enterprise Bean: MyBean
 */
public interface MyBeanHome extends javax.ejb.EJBHome {

	/**
	 * Creates a default instance of Session Bean: MyBean
	 */
	public ejbs.MyBean create()
		throws javax.ejb.CreateException,
		java.rmi.RemoteException;
}
