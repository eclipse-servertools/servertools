package ejbs;

/**
 * Local Home interface for Enterprise Bean: MyBean
 */
public interface MyBeanLocalHome extends javax.ejb.EJBLocalHome {

	/**
	 * Creates a default instance of Session Bean: MyBean
	 */
	public ejbs.MyBeanLocal create() throws javax.ejb.CreateException;
}
