package ejbs;

/**
 * Remote interface for Enterprise Bean: MyBean
 */
public interface MyBean extends javax.ejb.EJBObject {
}
