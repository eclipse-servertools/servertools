package ejbs;

/**
 * Local interface for Enterprise Bean: MyBean
 */
public interface MyBeanLocal extends javax.ejb.EJBLocalObject {
}
