package publish;

public class TestUtil2 {
	public static String sayHi(String s) {
		return "Hi 2, " + s;
	}
}