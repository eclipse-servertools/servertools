package testing;

public class MyConnectorClass {

}
