package test;

public class MyConnectorClass {

}
