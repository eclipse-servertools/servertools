package test;

public class MyOtherConnectorClass {

}
