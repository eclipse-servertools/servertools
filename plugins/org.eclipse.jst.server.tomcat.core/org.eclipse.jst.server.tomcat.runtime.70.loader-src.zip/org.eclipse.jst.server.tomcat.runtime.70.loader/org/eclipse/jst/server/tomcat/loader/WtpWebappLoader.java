/**********************************************************************
 * Copyright (c) 2010, 2013 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors:
 *	Igor Fedorenko & Fabrizio Giustina - Initial API and implementation
 **********************************************************************/
package org.eclipse.jst.server.tomcat.loader;

import java.io.File;
import java.util.StringTokenizer;

import org.apache.catalina.LifecycleException;
import org.apache.catalina.loader.WebappLoader;


public class WtpWebappLoader extends WebappLoader
{

	private String virtualClasspath;

	public WtpWebappLoader() {
		super();
		setLoaderClass("org.eclipse.jst.server.tomcat.loader.WtpWebappClassLoader");
	}

	public WtpWebappLoader(ClassLoader parent) {
		super(parent);
		setLoaderClass("org.eclipse.jst.server.tomcat.loader.WtpWebappClassLoader");
	}

	/**
	 * Tomcat digester will automatically set this property to the value of the "virtualClasspath" xml attribute.
	 * @param path ; separated list of path elements.
	 */
	public void setVirtualClasspath(String path) {
		virtualClasspath = path;
	}

	@Override
	public void startInternal() throws LifecycleException {
		StringTokenizer tkn = new StringTokenizer(virtualClasspath, ";");
		while (tkn.hasMoreTokens()) {
			File file = new File(tkn.nextToken());
			if (!file.exists()) {
				continue;
			}
			String path = file.getAbsoluteFile().toURI().toString();
			addRepository(path);
		}

		super.startInternal();
	}

}
