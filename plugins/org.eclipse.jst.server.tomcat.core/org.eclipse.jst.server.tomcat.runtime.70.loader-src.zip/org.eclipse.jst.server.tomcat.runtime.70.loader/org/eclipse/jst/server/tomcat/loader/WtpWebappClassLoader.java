/**********************************************************************
 * Copyright (c) 2013 SAS Institute, Inc and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors:
 *    SAS Institute, Inc - Initial API and implementation
 **********************************************************************/
package org.eclipse.jst.server.tomcat.loader;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.LinkedHashSet;

import org.apache.catalina.loader.WebappClassLoader;

public class WtpWebappClassLoader extends WebappClassLoader {

	public WtpWebappClassLoader() {
		super();
	}

	public WtpWebappClassLoader(ClassLoader parent) {
		super(parent);
	}

	/**
	 * It is necessary to wrap the findResources() method to remove a possible
	 * bogus entry that occurs when an entry is created using "files[i]" that may
	 * not exist at that location.
	 */
	@Override
	public Enumeration<URL> findResources(String name) throws IOException {
		Enumeration<URL> result = super.findResources(name);

		// Collect the information that is in the result
		LinkedHashSet<URL> filteredResult = new LinkedHashSet<URL>();
		URL firstURL = null;
		URL lastURL = null;
		boolean setFirstURL = true;
		while (result.hasMoreElements()) {
			lastURL = result.nextElement();
			if (setFirstURL) {
				firstURL = lastURL;
				setFirstURL = false;
			}
			filteredResult.add(lastURL);
		}

		// If more than one resource is found, we need to check the first or last in case it is bogus.
		if (filteredResult.size() > 1) {
			// If external resources came first, check the last URL
			if (searchExternalFirst) {
				if ("file".equals(lastURL.getProtocol().toLowerCase())) {
					File file = new File(lastURL.getPath());
					if (!file.exists()) {
						filteredResult.remove(lastURL);
					}
				}
			}
			// If external resources came last, check the first URL
			else {
				if ("file".equals(firstURL.getProtocol().toLowerCase())) {
					File file = new File(firstURL.getPath());
					if (!file.exists()) {
						filteredResult.remove(firstURL);
					}
				}
			}
		}

		// Reconstitute the result minus any bogus entry
		final Iterator<URL> wtpIterator = filteredResult.iterator();

		return new Enumeration<URL>() {
			@Override
			public boolean hasMoreElements() {
				return wtpIterator.hasNext();
			}

			@Override
			public URL nextElement() {
				return wtpIterator.next();
			}
		};
	}

}
