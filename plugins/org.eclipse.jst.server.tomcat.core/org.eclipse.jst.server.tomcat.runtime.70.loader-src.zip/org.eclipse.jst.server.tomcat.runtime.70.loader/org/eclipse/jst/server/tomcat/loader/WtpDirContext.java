/**********************************************************************
 * Copyright (c) 2010 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors:
 *    Igor Fedorenko & Fabrizio Giustina - Initial API and implementation
 **********************************************************************/
package org.eclipse.jst.server.tomcat.loader;

import java.io.File;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;
import java.util.Vector;

import javax.naming.NamingException;
import javax.naming.directory.Attributes;

import org.apache.naming.NamingEntry;
import org.apache.naming.resources.FileDirContext;

/**
 * Extended FileDirContext implementation that will allow loading of tld files
 * from the META-INF directory (or subdirectories) in classpath. This will fully
 * mimic the behavior of compressed jars also when using unjarred resources.
 * @author Fabrizio Giustina
 */
public class WtpDirContext extends FileDirContext {
	// List of virtual paths
	private List<String> virtualPaths;
	
	// Map of tld file names to File
	private Map<String, File> virtualMappings;

	// Map of tag and tagx file names to File
	private Map<String, File> tagfileMappings;

	// Map of resource folder names to list of resource directories
	private Map<String, List<String>> mappedResourcePaths;

	// The virtual classpath setting
	private String virtualClasspath = "";

	// The extra resource paths
	private String extraResourcePaths = "";

	public WtpDirContext() {
		super();
	}

	public WtpDirContext(Hashtable<String, Object> env) {
		super(env);
	}
	/**
	 * Tomcat digester will automatically set this property to the value of the
	 * "virtualClasspath" xml attribute.
	 * @param path ; separated list of path elements.
	 */
	public void setVirtualClasspath(String path) {
		virtualClasspath = path;
	}

	/**
	 * Tomcat digester will automatically set this property to the value of the
	 * "extraResourcePaths" xml attribute.
	 * @param path ; separated list of path elements.
	 */
	public void setExtraResourcePaths(String path) {
		extraResourcePaths = path;
	}

	@Override
	public void allocate() {
		super.allocate();
		virtualPaths = new Vector<String>();
		virtualMappings = new Hashtable<String, File>();
		tagfileMappings = new Hashtable<String, File>();
		mappedResourcePaths = new Hashtable<String, List<String>>();

		StringTokenizer tkn = new StringTokenizer(virtualClasspath, ";");
		while (tkn.hasMoreTokens()) {
			String virtualPath = tkn.nextToken();
			virtualPaths.add(virtualPath);
			File file = new File(virtualPath, "META-INF");

			if (!file.exists() || !file.isDirectory()) {
				continue;
			}
			scanForTlds(file);
		}

		tkn = new StringTokenizer(extraResourcePaths, ";");
		while (tkn.hasMoreTokens()) {
			String resSpec = tkn.nextToken();
			if (resSpec.length() > 0) {
				int idx = resSpec.indexOf('|');
				if (idx <= 0) {
					List<String> resourcePaths = mappedResourcePaths.get("");
					if (resourcePaths == null) {
						resourcePaths = new ArrayList<String>();
						mappedResourcePaths.put("", resourcePaths);
					}
					if (idx < 0) {
						resourcePaths.add(resSpec);
					}
					else {
						resourcePaths.add(resSpec.substring(1));
					}
				}
				else {
					String path = resSpec.substring(0, idx);
					String dir = resSpec.substring(idx + 1);
					List<String> resourcePaths = mappedResourcePaths.get(path);
					if (resourcePaths == null) {
						resourcePaths = new ArrayList<String>();
						mappedResourcePaths.put(path, resourcePaths);
					}
					resourcePaths.add(dir);
				}
				// Set allowLinking since there can be no canonical path
				setAllowLinking(true);
			}
		}
	}

	@Override
	public void release() {
		super.release();
		virtualPaths = null;
		virtualMappings = null;
		tagfileMappings = null;
		mappedResourcePaths = null;
	}

	@Override
	public Attributes getAttributes(String name) throws NamingException {

		if (name.startsWith("/WEB-INF/") && name.endsWith(".tld")) {
			String tldName = name.substring(name.lastIndexOf("/") + 1);
			if (virtualMappings != null && virtualMappings.containsKey(tldName)) {
				return new FileResourceAttributes(virtualMappings.get(tldName));
			}
		} else if (name.startsWith("/META-INF/tags") && name.endsWith(".tag")
				|| name.endsWith(".tagx")) {

			// already loaded tag file
			if (tagfileMappings != null && tagfileMappings.containsKey(name)) {
				return new FileResourceAttributes(tagfileMappings.get(name));
			}

			if (virtualPaths != null) {
				// unknown tagfile, search for it in virtualClasspath
				for (String virtualPath : virtualPaths) {
					File file = new File(virtualPath, name);
					if (file.exists()) {
						tagfileMappings.put(name, file);
						return new FileResourceAttributes(file);
					}
				}
			}
		}

		Attributes superAttr;
		NamingException superEx;
		try {
			superAttr = super.getAttributes(name);
			return superAttr;
		} catch (NamingException ex) {
			superAttr = null;
			superEx = ex;
		}
		if (mappedResourcePaths != null) {
			for (Map.Entry<String, List<String>> mapping : mappedResourcePaths.entrySet()) {
				String path = mapping.getKey();
				List<String> dirList = mapping.getValue();
				// Return attributes of first entry only, should there be more than one
				String resourcesDir = dirList.get(0);
				if (name.equals(path)) {
					File f = new File(resourcesDir);
					if (f.exists() && f.canRead()) {
						return new FileResourceAttributes(f);
					}
				}
				path += "/";
				if (name.startsWith(path)) {
					String res = name.substring(path.length());
					File f = new File (resourcesDir + "/" + res);
					if (f.exists() && f.canRead()) {
						return new FileResourceAttributes(f);
					}
				}
			}
		}
		throw superEx;
	}

	@Override
	protected File file(String name) {
		File file = super.file(name);
		if (file != null) {
			return file;
		}
		if (mappedResourcePaths != null) {
			// If not found under docBase, try our other resources
			if (mappedResourcePaths != null) {
				for (Map.Entry<String, List<String>> mapping : mappedResourcePaths.entrySet()) {
					String path = mapping.getKey();
					List<String> dirList = mapping.getValue();
					if (name.equals(path)) {
						for (String resourcesDir : dirList) {
							file = new File(resourcesDir);
							if (file.exists() && file.canRead()) {
								return file;
							}
						}
					}
					if (name.startsWith(path + "/")) {
						String res = name.substring(path.length());
						for (String resourcesDir : dirList) {
							file = new File (resourcesDir, res);
							if (file.exists() && file.canRead()) {
								return file;
							}
						}
					}
				}
			}
		}
		return null;
	}

	@Override
	protected ArrayList<NamingEntry> list(File file) {
		ArrayList<NamingEntry> entries = super.list(file);
		if ("WEB-INF".equals(file.getName())) {
			entries.addAll(getVirtualNamingEntries());
		}
		if (mappedResourcePaths != null) {
			// Add appropriate entries from the extra resource paths
			String absPath = file.getAbsolutePath();
			if (absPath.startsWith(getDocBase() + File.separator)) {
				String relPath = absPath.substring(getDocBase().length());
				if (!(File.separator + "WEB-INF" + File.separator + "lib").equals(relPath)) {
					String fsRelPath = relPath.replace(File.separatorChar, '/');
					for (Map.Entry<String, List<String>> mapping : mappedResourcePaths.entrySet()) {
						String path = mapping.getKey();
						List<String> dirList = mapping.getValue();
						if (fsRelPath.equals(path)) {
							for (String resourcesDir : dirList) {
								File f = new File(resourcesDir);
								if (f.exists() && f.canRead() && f.isDirectory()) {
									ArrayList<NamingEntry> virtEntries = super.list(f);
									entries.addAll(virtEntries);
								}
							}
						}
						else if (fsRelPath.startsWith(path + "/")) {
							String res = relPath.substring(path.length());
							for (String resourcesDir : dirList) {
								File f = new File (resourcesDir, res);
								if (f.exists() && f.canRead() && f.isDirectory()) {
									ArrayList<NamingEntry> virtEntries = super.list(f);
									entries.addAll(virtEntries);
								}
							}
						}
					}
				}
			}
		}
		return entries;
	}

	@Override
	public Object doLookup(String name) {
		if (name.startsWith("/WEB-INF/") && name.endsWith(".tld")) {
			String tldName = name.substring(name.lastIndexOf("/") + 1);
			if (virtualMappings != null && virtualMappings.containsKey(tldName)) {
				return new FileResource(virtualMappings.get(tldName));
			}
		} else if (tagfileMappings != null && name.startsWith("/META-INF/tags")
				&& (name.endsWith(".tag") || name.endsWith(".tagx"))) {
			// already loaded tag file
			return new FileResource(tagfileMappings.get(name));
		} 

		Object retSuper = super.doLookup(name);

		if (retSuper == null && mappedResourcePaths != null) {
			// Perform lookup using the extra resource paths
			for (Map.Entry<String, List<String>> mapping : mappedResourcePaths.entrySet()) {
				String path = mapping.getKey();
				List<String> dirList = mapping.getValue();
				if (name.equals(path)) {
					for (String resourcesDir : dirList) {
						File f = new File(resourcesDir);
						if (f.exists() && f.canRead()) {
							if (f.isFile()) {
								return new FileResource(f);
							}
							else {
								// TODO Handle directory
							}
						}
					}
				}
				path += "/";
				if (name.startsWith(path)) {
					String res = name.substring(path.length());
					for (String resourcesDir : dirList) {
						File f = new File (resourcesDir + "/" + res);
						if (f.exists() && f.canRead()) {
							if (f.isFile()) {
								return new FileResource(f);
							}
							else {
								// TODO Handle directory
							}
						}
					}
				}
			}
		}
		return retSuper;
	}

	@Override
	protected String doGetRealPath(String path) {
		// Check tld and tag files
		if (path.startsWith("/WEB-INF/") && path.endsWith(".tld")) {
			String tldName = path.substring(path.lastIndexOf("/") + 1);
			if (virtualMappings != null && virtualMappings.containsKey(tldName)) {
				return virtualMappings.get(tldName).getAbsolutePath();
			}
		} else if (tagfileMappings != null && path.startsWith("/META-INF/tags")
				&& (path.endsWith(".tag") || path.endsWith(".tagx"))) {
			// already loaded tag file
			return tagfileMappings.get(path).getAbsolutePath();
		}
		// Try to find mapped path except for "/" and "/WEB-INF/lib" which must be
		// relative to docBase.
		if (!"/".equals(path) && !"/WEB-INF/lib".equals(path)&& mappedResourcePaths != null) {
			// Perform lookup using the extra resource paths
			for (Map.Entry<String, List<String>> mapping : mappedResourcePaths.entrySet()) {
				String srcPath = mapping.getKey();
				List<String> dirList = mapping.getValue();
				if (path.equals(srcPath)) {
					for (String resourcesDir : dirList) {
						File f = new File(resourcesDir);
						if (f.exists() && f.canRead()) {
							f.getAbsolutePath();
						}
					}
				}
				srcPath += "/";
				if (path.startsWith(srcPath)) {
					String res = path.substring(srcPath.length());
					for (String resourcesDir : dirList) {
						File f = new File (resourcesDir + "/" + res);
						if (f.exists() && f.canRead()) {
							return f.getAbsolutePath();
						}
					}
				}
			}
		}

		// Call super for path "/", "/WEB-INF/lib" or as last resort
		return super.doGetRealPath(path);
	}
	
	private void scanForTlds(File dir) {

		File[] files = dir.listFiles();
		for (int j = 0; j < files.length; j++) {
			File file = files[j];

			if (file.isDirectory()) {
				scanForTlds(file);
			} else if (file.getName().endsWith(".tld")) {
				virtualMappings.put("~" + System.currentTimeMillis() + "~"
						+ file.getName(), file);
			}
		}

	}

	private List<NamingEntry> getVirtualNamingEntries() {
		List<NamingEntry> virtual = new ArrayList<NamingEntry>();
		if (virtualMappings != null) {
			for (String name : virtualMappings.keySet()) {
				File file = virtualMappings.get(name);
				NamingEntry entry = new NamingEntry(name, new FileResource(file),
						NamingEntry.ENTRY);
				virtual.add(entry);
			}
		}
		return virtual;
	}

}
