/**********************************************************************
 * Copyright (c) 2007,2010 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors:
 *    Fabrizio Giustina - Initial API and implementation
 **********************************************************************/
package org.eclipse.jst.server.tomcat.loader;

import java.io.File;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;
import java.util.Vector;

import javax.naming.NamingException;
import javax.naming.directory.Attributes;

import org.apache.naming.NamingEntry;
import org.apache.naming.resources.FileDirContext;

/**
 * Extended FileDirContext implementation that will allow loading of tld files
 * from the META-INF directory (or subdirectories) in classpath. This will fully
 * mimic the behavior of compressed jars also when using unjarred resources.
 * @author Fabrizio Giustina
 */
public class WtpDirContext extends FileDirContext {
	// List of virtual paths
	private List virtualPaths;
	
	// Map of tld file names to File
	private Map virtualMappings;

	// Map of tag and tagx file names to File
	private Map tagfileMappings;

	// Map of resource folder names to list of resource directories
	private Map mappedResourcePaths;

	// The virtual classpath setting
	private String virtualClasspath = "";

	// The extra resource paths
	private String extraResourcePaths = "";

	/**
	 * Tomcat digester will automatically set this property to the value of the
	 * "virtualClasspath" xml attribute.
	 * @param path ; separated list of path elements.
	 */
	public void setVirtualClasspath(String path) {
		virtualClasspath = path;
	}

	/**
	 * Tomcat digester will automatically set this property to the value of the
	 * "extraResourcePaths" xml attribute.
	 * @param path ; separated list of path elements.
	 */
	public void setExtraResourcePaths(String path) {
		extraResourcePaths = path;
	}

	public void allocate() {
		super.allocate();
		virtualPaths = new Vector(); // new Vector<String>();
		virtualMappings = new Hashtable(); // new Hashtable<String, File>();
		tagfileMappings = new Hashtable(); // new Hashtable<String, File>();
		mappedResourcePaths = new Hashtable(); // new Hashtable<String, List<String>>();

		StringTokenizer tkn = new StringTokenizer(virtualClasspath, ";");
		while (tkn.hasMoreTokens()) {
			String virtualPath = tkn.nextToken();
			virtualPaths.add(virtualPath);
			File file = new File(virtualPath, "META-INF");

			if (!file.exists() || !file.isDirectory()) {
				continue;
			}
			scanForTlds(file);
		}
		tkn = new StringTokenizer(extraResourcePaths, ";");
		while (tkn.hasMoreTokens()) {
			String resSpec = tkn.nextToken();
			if (resSpec.length() > 0) {
				int idx = resSpec.indexOf('|');
				if (idx <= 0) {
					List resourcePaths = (List)mappedResourcePaths.get("");
					if (resourcePaths == null) {
						resourcePaths = new ArrayList();
						mappedResourcePaths.put("", resourcePaths);
					}
					if (idx < 0) {
						resourcePaths.add(resSpec);
					}
					else {
						resourcePaths.add(resSpec.substring(1));
					}
				}
				else {
					String path = resSpec.substring(0, idx);
					String dir = resSpec.substring(idx + 1);
					List resourcePaths = (List)mappedResourcePaths.get(path);
					if (resourcePaths == null) {
						resourcePaths = new ArrayList();
						mappedResourcePaths.put(path, resourcePaths);
					}
					resourcePaths.add(dir);
				}
				// Set allowLinking since there can be no canonical path
				setAllowLinking(true);
			}
		}
	}

	public void release() {
		super.release();
		virtualPaths = null;
		virtualMappings = null;
		tagfileMappings = null;
		mappedResourcePaths = null;
	}

	public Attributes getAttributes(String name) throws NamingException {
		if (name.startsWith("/WEB-INF/") && name.endsWith(".tld")) {
			String tldName = name.substring(name.lastIndexOf("/") + 1);
			if (virtualMappings.containsKey(tldName)) {
				return new FileResourceAttributes((File) virtualMappings.get(tldName));
			}
		} else if (name.startsWith("/META-INF/tags") && name.endsWith(".tag")
				|| name.endsWith(".tagx")) {

			// already loaded tag file
			if (tagfileMappings.containsKey(name)) {
				return new FileResourceAttributes((File) tagfileMappings.get(name));
			}

			// unknown tagfile, search for it in virtualClasspath
			Iterator iterator = virtualPaths.iterator();
			while ( iterator.hasNext()) {
				String virtualPath = (String) iterator.next();
				File file = new File(virtualPath, name);
				if (file.exists()) {
					tagfileMappings.put(name, file);
					return new FileResourceAttributes(file);
				}
			}
		}

		Attributes superAttr;
		NamingException superEx;
		try {
			superAttr = super.getAttributes(name);
			return superAttr;
		} catch (NamingException ex) {
			superAttr = null;
			superEx = ex;
		}
		Iterator iterator = mappedResourcePaths.entrySet().iterator();
		while (iterator.hasNext()) {
			Map.Entry mapping = (Map.Entry)iterator.next();
			String path = (String)mapping.getKey();
			List dirList = (List)mapping.getValue();
			// Return attributes of first entry only, should there be more than one
			String resourcesDir = (String)dirList.get(0);
			if (name.equals(path)) {
				File f = new File(resourcesDir);
				if (f.exists() && f.canRead()) {
					return new FileResourceAttributes(f);
				}
			}
			path += "/";
			if (name.startsWith(path)) {
				String res = name.substring(path.length());
				File f = new File (resourcesDir + "/" + res);
				if (f.exists() && f.canRead()) {
					return new FileResourceAttributes(f);
				}
			}
		}
		if (superAttr == null) {
			throw superEx;
		}
		return superAttr;
	}

	protected File file(String name) {
		File file = super.file(name);
		if (file != null) {
			return file;
		}
		// If not found under docBase, try our other resources
		Iterator iterator = mappedResourcePaths.entrySet().iterator();
		while (iterator.hasNext()) {
			Map.Entry mapping = (Map.Entry)iterator.next();
			String path = (String)mapping.getKey();
			List dirList = (List)mapping.getValue();
			if (name.equals(path)) {
				Iterator iterator2 = dirList.iterator();
				while(iterator2.hasNext()) {
					String resourcesDir = (String)iterator2.next();
					file = new File(resourcesDir);
					if (file.exists() && file.canRead()) {
						return file;
					}
				}
			}
			if (name.startsWith(path + "/")) {
				String res = name.substring(path.length());
				Iterator iterator2 = dirList.iterator();
				while(iterator2.hasNext()) {
					String resourcesDir = (String)iterator2.next();
					file = new File (resourcesDir, res);
					if (file.exists() && file.canRead()) {
						return file;
					}
				}
			}
		}
		return null;
	}

	protected ArrayList list(File file) {
		ArrayList entries = super.list(file);
		if ("WEB-INF".equals(file.getName())) {
			entries.addAll(getVirtualNamingEntries());
		}
		// Add appropriate entries from the extra resource paths
		String absPath = file.getAbsolutePath();
		if (absPath.startsWith(getDocBase() + File.separator)) {
			String relPath = absPath.substring(getDocBase().length());
			if (!(File.separator + "WEB-INF" + File.separator + "lib").equals(relPath)) {
				String fsRelPath = relPath.replace(File.separatorChar, '/');
				Iterator iterator = mappedResourcePaths.entrySet().iterator();
				while (iterator.hasNext()) {
					Map.Entry mapping = (Map.Entry)iterator.next();
					String path = (String)mapping.getKey();
					List dirList = (List)mapping.getValue();
					if (fsRelPath.equals(path)) {
						Iterator iterator2 = dirList.iterator();
						while(iterator2.hasNext()) {
							String resourcesDir = (String)iterator2.next();
							File f = new File(resourcesDir);
							if (f.exists() && f.canRead() && f.isDirectory()) {
								ArrayList virtEntries = super.list(f);
								entries.addAll(virtEntries);
							}
						}
					}
					else if (fsRelPath.startsWith(path + "/")) {
						String res = relPath.substring(path.length());
						Iterator iterator2 = dirList.iterator();
						while(iterator2.hasNext()) {
							String resourcesDir = (String)iterator2.next();
							File f = new File (resourcesDir, res);
							if (f.exists() && f.canRead() && f.isDirectory()) {
								ArrayList virtEntries = super.list(f);
								entries.addAll(virtEntries);
							}
						}
					}
				}
			}
		}
		return entries;
	}

	public Object lookup(String name) throws NamingException {
		if (name.startsWith("/WEB-INF/") && name.endsWith(".tld")) {
			String tldName = name.substring(name.lastIndexOf("/") + 1);
			if (virtualMappings.containsKey(tldName)) {
				return new FileResource((File) virtualMappings.get(tldName));
			}
		} else if (name.startsWith("/META-INF/tags") && name.endsWith(".tag")
				|| name.endsWith(".tagx")) {

			// already loaded tag file
			return new FileResource((File) tagfileMappings.get(name));
		}

		Object retSuper;
		try {
			retSuper = super.lookup(name);
			return retSuper;
		} catch (NamingException ex) {
			retSuper = null;
		}
		// Perform lookup using the extra resource paths
		Iterator iterator = mappedResourcePaths.entrySet().iterator();
		while (iterator.hasNext()) {
			Map.Entry mapping = (Map.Entry)iterator.next();
			String path = (String)mapping.getKey();
			List dirList = (List)mapping.getValue();
			if (name.equals(path)) {
				Iterator iterator2 = dirList.iterator();
				while(iterator2.hasNext()) {
					String resourcesDir = (String)iterator2.next();
					File f = new File(resourcesDir);
					if (f.exists() && f.canRead()) {
						if (f.isFile()) {
							return new FileResource(f);
						}
						else {
							// TODO Handle directory
						}
					}
				}
			}
			path += "/";
			if (name.startsWith(path)) {
				String res = name.substring(path.length());
				Iterator iterator2 = dirList.iterator();
				while(iterator2.hasNext()) {
					String resourcesDir = (String)iterator2.next();
					File f = new File (resourcesDir + "/" + res);
					if (f.exists() && f.canRead()) {
						if (f.isFile()) {
							return new FileResource(f);
						}
						else {
							// TODO Handle directory
						}
					}
				}
			}
		}
		if (retSuper == null) {	
			throw new NamingException();
		}
		return retSuper;
	}

	private void scanForTlds(File dir) {

		File[] files = dir.listFiles();
		for (int j = 0; j < files.length; j++) {
			File file = files[j];

			if (file.isDirectory()) {
				scanForTlds(file);
			} else if (file.getName().endsWith(".tld")) {
				virtualMappings.put("~" + System.currentTimeMillis() + "~"
						+ file.getName(), file);
			}
		}

	}

	private List getVirtualNamingEntries() {
		List virtual = new ArrayList();
		for (Iterator iter = virtualMappings.keySet().iterator(); iter
				.hasNext();) {
			String name = (String) iter.next();
			File file = (File) virtualMappings.get(name);
			NamingEntry entry = new NamingEntry(name, new FileResource(file),
					NamingEntry.ENTRY);
			virtual.add(entry);
		}
		return virtual;
	}

}
